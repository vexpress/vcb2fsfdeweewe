import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-check-point',
  templateUrl: './add-check-point.component.html',
  styleUrls: ['./add-check-point.component.scss']
})
export class AddCheckPointComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
